SURVIVAL 100 モンスター追加パック

concept/monster_expansion_visual_preview.png: デザイン参考画像
 data/monster_manifest.json: 30体の設定マニフェスト
IMPLEMENTATION_REQUEST_JA.md: AI Studio向け依頼文

重要：このZIPはデザイン参考画像と実装仕様です。30体分の個別透過スプライト・完成アニメーション素材は含みません。AI Studioに個別素材の作成・登録を依頼してください。

ミミック：各50日ブロックにつき必ず1回、ブロック内ランダム日に出現。撃破報酬は70%で10,000コイン、30%で未取得装備1個。未取得装備がなければ10,000コイン。