# 素材一覧・対応表（日本語）

| フォルダ | ファイル | 役割 | 注意 |
|---|---|---|---|
| `assets/characters/` | `character-atlas-4x4.png` | 主人公・職業キャラのデザイン参考 | 4x4の参考シート。切り出し・透過処理が必要 |
| `assets/characters/` | `character-atlas-alternate-4x4.png` | キャラクター別案 | 4x4の参考シート。最終採用前に既存職業IDと照合 |
| `assets/characters/` | `classes-visual-reference.png` | 添付完成イメージから切り出した職業一覧 | UI内の参考画像。ゲーム素材として直接使わない |
| `assets/weapons/` | `equipment-icons-atlas-5x4.png` | 武器・盾・防具・アクセサリーのアイコン案 | 5x4参考シート。切り出し・透過処理が必要 |
| `assets/weapons/` | `equipment-shop-visual-reference.png` | ショップの装備一覧と価格表示 | UIレイアウト参考 |
| `assets/monsters/` | `monster-boss-visual-reference.png` | スライム、ゴブリン、スケルトン、狼、オーク、ドラゴン等 | UI内の参考画像。既存monster IDに合わせて個別化 |
| `assets/backgrounds/` | `stage-backgrounds-visual-reference.png` | 森、遺跡、溶岩、雪山、魔王城 | ステージ背景の構図・色調参考 |
| `assets/skills-effects/` | `skill-effects-visual-reference.png` | スキルアイコン・攻撃エフェクト | 既存スキルIDに合わせて個別化 |
| `assets/ui/` | `ui-visual-reference.png` | HUD、金枠、ショップ、タブ等 | UIのレイアウト・配色参考 |
| `reference/` | `target-game-design.jpeg` | ユーザーが選んだ最終デザイン画像 | 最優先のビジュアルゴール |
| `reference/` | `gameplay-visual-reference.png` | 戦闘画面の参考 | 戦闘レイアウト・画面密度の参考 |

## 素材の分類ルール
- キャラクターとモンスターは別フォルダ。
- 武器と防具は別フォルダ（現時点のアイコンアトラスは武器・防具混在のため、切り出し後に分離）。
- 背景はステージごとに別ファイル。
- スキルアイコンと発動エフェクトは区別する。
- UI素材はゲーム内スプライトと混ぜない。
- 最終ファイル名は `hero-warrior-idle.png` のように小文字英数字とハイフンで命名し、既存データIDとの対応表を作る。
