# SURVIVAL 100 — AI Studio改修パッケージ

## 使い方
1. このフォルダ内の既存 React + TypeScript + Vite プロジェクトをGoogle AI Studio Buildで開く。
2. `AI_STUDIO_PROMPT_JA.md` の内容をAI Studioに貼り付け、同時にこのZIPを添付する。
3. `reference/target-game-design.jpeg` を最優先の完成イメージとして指定する。
4. AI Studioにまずプロジェクト構成と素材を確認させ、実装後にビルド検証させる。

## ZIP構成
- `src/` — 元のゲームコード（改修ベース）
- `public/assets/` — 既存のAI Studio画像等
- `assets/characters/` — キャラクター参考アトラス（4x4）
- `assets/weapons/` — 武器・防具アイコン参考アトラス（5x4）とショップ参考画像
- `assets/monsters/` — モンスター・ボスのデザイン参考画像
- `assets/backgrounds/` — ステージ背景のデザイン参考画像
- `assets/skills-effects/` — スキル・エフェクトの参考画像
- `assets/ui/` — UIデザイン参考画像
- `reference/` — 完成イメージとゲームプレイ参考画像
- `AI_STUDIO_PROMPT_JA.md` — AI Studioに貼る改修指示
- `ASSET_INDEX_JA.md` — 素材の用途一覧
- `ECONOMY_BALANCE.md` — 経済調整の方針

## 重要
素材アトラスは現段階では「デザイン参考」です。背景が市松模様として描かれている画像は透過PNGではありません。AI Studioには、個別セルに切り出し、背景を除去または描き直し、実際のゲーム用素材として整理してから実装するよう指示しています。画像全体をそのままゲーム画面に貼らないでください。
