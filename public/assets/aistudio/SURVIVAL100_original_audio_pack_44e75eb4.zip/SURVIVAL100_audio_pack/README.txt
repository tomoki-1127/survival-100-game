SURVIVAL 100 Original Audio Pack

9 original synthesized BGM loops and 10 sound effects.
BGM: home/shop, forest, cave, wasteland, icefield, demon realm, boss, Day 100 final boss, endless.
SFX: sword slash, magic, level up, coin, boss arrival, item pickup, purchase, skill, death, victory.
WAV mono 16kHz 16-bit PCM. These are original synthesized retro-game audio drafts, not live orchestral recordings.
Copy public/audio into the project public/audio folder. Then reference /audio/<filename> in the game audio manager.
